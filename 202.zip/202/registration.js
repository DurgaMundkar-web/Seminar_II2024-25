document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");

  form.addEventListener("submit", function (e) {
    // Collect all input values
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const dob = document.getElementById("dob").value;
    const address = document.getElementById("address").value.trim();
    const course = document.getElementById("course").value;

    // Email pattern
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Phone pattern (10 digits)
    const phonePattern = /^[0-9]{10}$/;

    // Validate each field
    if (name === "" || email === "" || phone === "" || dob === "" || address === "" || course === "") {
      alert("Please fill in all the required fields.");
      e.preventDefault();
      return;
    }

    if (!emailPattern.test(email)) {
      alert("Please enter a valid email address.");
      e.preventDefault();
      return;
    }

    if (!phonePattern.test(phone)) {
      alert("Phone number must be 10 digits.");
      e.preventDefault();
      return;
    }

    // Optional: Validate date of birth (user must be at least 17 years old)
    const birthDate = new Date(dob);
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();
    if (age < 17) {
      alert("You must be at least 17 years old to register.");
      e.preventDefault();
      return;
    }

    // If all valid
    alert("Registration Successful!");
  });
});