<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $course = $_POST['course'];

    $sql = "INSERT INTO users (username, password, email, phone, dob, address, course)
            VALUES ('$username', '$password', '$email', '$phone', '$dob', '$address', '$course')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Registration Successful!'); window.location.href='login.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Hostel Registration</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    /* Global Styles */
    body {
      font-family: Arial, sans-serif;
      background-color: #e8f0fe;
      margin: 0;
      padding: 0;
    }

    /* Container */
    .container {
      width: 50%;
      margin: 50px auto;
      background-color: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    /* Heading */
    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
    }

    /* Labels */
    label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
      color: #333;
    }

    /* Inputs, textarea, select */
    input[type="text"],
    input[type="email"],
    input[type="tel"],
    input[type="date"],
    input[type="password"],
    select,
    textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
      font-size: 14px;
    }

    textarea {
      resize: vertical;
    }

    /* Button Group */
    .btn-group {
      display: flex;
      justify-content: space-between;
    }

    .btn-group input[type="submit"],
    .btn-group input[type="reset"] {
      width: 48%;
      padding: 10px;
      font-size: 16px;
      font-weight: bold;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: 0.3s;
    }

    .btn-group input[type="submit"] {
      background-color: #4CAF50;
      color: white;
    }

    .btn-group input[type="submit"]:hover {
      background-color: #45a049;
    }

    .btn-group input[type="reset"] {
      background-color: #f44336;
      color: white;
    }

    .btn-group input[type="reset"]:hover {
      background-color: #da190b;
    }

    /* Link */
    p {
      text-align: center;
      margin-top: 20px;
    }

    a {
      color: #007BFF;
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .container {
        width: 90%;
      }

      .btn-group {
        flex-direction: column;
      }

      .btn-group input {
        width: 100%;
        margin-bottom: 10px;
      }
    }
  </style>
</head>
<body>
  <script src="register.js"></script>
  <div class="container">
    <h2>Hostel Registration Form</h2>
    <form action="register.php" method="post">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>

      <label for="email">Email</label>
      <input type="email" id="email" name="email" required>

      <label for="phone">Phone</label>
      <input type="tel" id="phone" name="phone" required>

      <label for="dob">Date of Birth</label>
      <input type="date" id="dob" name="dob" required>

      <label for="address">Address</label>
      <textarea id="address" name="address" rows="3" required></textarea>

      <label for="course">Course</label>
      <select name="course" id="course" required>
        <option value="BTech">BTech</option>
        <option value="BCS">BCS</option>
        <option value="BCA">BCA</option>
      </select>

      <div class="btn-group">
        <input type="submit" value="Register">
        <input type="reset" value="Reset">
      </div>
    </form>
    <p>Already have an account? <a href="login.php">Login here</a></p>
  </div>
</body>
</html>
