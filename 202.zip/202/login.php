<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            header("Location: index.html");
            exit();
        } else {
            echo "<script>alert('Wrong password!'); window.location.href='register.php';</script>";
        }
    } else {
        echo "<script>alert('User not found! Please register first.'); window.location.href='register.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Hostel Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    /* Global Styles */
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f4f8;
      margin: 0;
      padding: 0;
    }

    /* Container */
    .login-container {
      width: 40%;
      margin: 80px auto;
      background-color: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }

    /* Heading */
    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
    }

    /* Form Labels */
    label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
      color: #333;
    }

    /* Inputs */
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 14px;
    }

    /* Submit Button */
    button {
      width: 100%;
      padding: 12px;
      background-color: #4CAF50;
      color: white;
      font-size: 16px;
      font-weight: bold;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #45a049;
    }

    /* Register Link */
    p {
      text-align: center;
      margin-top: 20px;
    }

    a {
      color: #007BFF;
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .login-container {
        width: 90%;
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <script src="login.js"></script>
  <div class="login-container">
    <form method="post" action="login.php">
      <h1>Login to Your Account</h1>

      <label for="username">Username</label>
      <input type="text" id="username" name="username" required>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>

      <button type="submit">Login</button>

      <p>Don't have an account? <a href="register.php">Register here</a></p>
    </form>
  </div>
</body>
</html>
