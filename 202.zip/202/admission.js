document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");

  form.addEventListener("submit", function (e) {
    // Get form values
    const fullname = document.getElementById("fullname").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const course = document.getElementById("course").value.trim();
    const address = document.getElementById("address").value.trim();
    const room = document.getElementById("room").value;

    // Regex patterns
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phonePattern = /^[0-9]{10}$/;

    // Check empty
    if (
      fullname === "" ||
      email === "" ||
      phone === "" ||
      course === "" ||
      address === "" ||
      room === "" ||
      room === "--"
    ) {
      alert("Please fill in all required fields.");
      e.preventDefault();
      return;
    }

    // Validate email
    if (!emailPattern.test(email)) {
      alert("Please enter a valid email address.");
      e.preventDefault();
      return;
    }

    // Validate phone
    if (!phonePattern.test(phone)) {
      alert("Phone number must be exactly 10 digits.");
      e.preventDefault();
      return;
    }

    alert("Admission Form Submitted Successfully!");
  });
});