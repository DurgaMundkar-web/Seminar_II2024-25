document.addEventListener('DOMContentLoaded', () => {
  const themeToggle = document.getElementById('theme-toggle');
  const sendBtn = document.getElementById('send-btn');
  const userInput = document.getElementById('user-input');
  const chatHistory = document.getElementById('chat-history');
  const conversationList = document.getElementById('conversation-list');
  const newConversationBtn = document.getElementById('new-conversation-btn');

  // Toggle dark mode
  themeToggle.addEventListener('change', () => {
    document.body.classList.toggle('dark-mode', themeToggle.checked);
  });

  // Send user message
  sendBtn.addEventListener('click', () => {
    const userMessage
::contentReference[oaicite:0]{index=0}
 
