<?php
include 'db1.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];
    $address = $_POST['address'];
    $year = $_POST['room'];

    $sql = "INSERT INTO admissions (fullname, email, phone, course, address, year)
            VALUES ('$fullname', '$email', '$phone', '$course', '$address', '$year')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Application has been submitted'); window.location.href='admission.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Hostel Admission Form</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: Arial;
      background-color: #f1f1f1;
      margin: 0;
      padding: 0;
    }

    .form-container {
      width: 50%;
      margin: 40px auto;
      background-color: #ffffff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 25px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    label {
      font-weight: bold;
      display: block;
      margin-bottom: 5px;
    }

    input[type="text"],
    input[type="email"],
    input[type="tel"],
    select,
    textarea {
      width: 100%;
      padding: 10px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    textarea {
      resize: vertical;
    }

    button {
      background-color: #4CAF50;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      width: 100%;
      margin-top: 10px;
    }

    button:disabled {
      background-color: #ccc;
    }

    a {
      color: blue;
    }

    @media (max-width: 768px) {
      .form-container {
        width: 90%;
      }
    }
  </style>
</head>
<body>
  <script src="admission.js"></script>

<div class="form-container">
  <form class="admission-form" method="post" action="">
    <h2>Hostel Admission Form</h2>

    <div class="form-group">
      <label for="fullname">Full Name</label>
      <input type="text" id="fullname" name="fullname" required>
    </div>

    <div class="form-group">
      <label for="email">Email Address</label>
      <input type="email" id="email" name="email" required>
    </div>

    <div class="form-group">
      <label for="phone">Phone Number</label>
      <input type="tel" id="phone" name="phone" required>
    </div>

    <div class="form-group">
      <label for="course">Course / Department</label>
      <input type="text" id="course" name="course" required>
    </div>

    <div class="form-group">
      <label for="address">Permanent Address</label>
      <textarea id="address" name="address" rows="3" required></textarea>
    </div>

    <div class="form-group">
      <label for="room">Current Year</label>
      <select id="room" name="room" required>
        <option value="">-- Select year --</option>
        <option value="1st">First year</option>
        <option value="2nd">Second year</option>
        <option value="3rd">Third year</option>
        <option value="4th">Final year</option>
      </select>
    </div>

    <label>
      <input type="checkbox" id="agreeCheckbox"> Before submit, please read all <a href="rules.html">Rules and Regulations</a>
    </label><br><br>

    <button type="submit" id="submitButton" disabled>Submit Application</button>
  </form>
</div>

<script>
  const checkbox = document.getElementById('agreeCheckbox');
  const submitButton = document.getElementById('submitButton');

  checkbox.addEventListener('change', function () {
    submitButton.disabled = !this.checked;
  });
</script>

</body>
</html>
