document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('feedbackform');
  const reviewsContainer = document.getElementById('reviews-container');

  // Load existing reviews from localStorage
  loadReviews();

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const rating = document.querySelector('input[name="rating"]:checked')?.value || 'N/A';
    const emoji = document.getElementById('emoji').value;
    const category = document.getElementById('category').value;
    const comments = document.querySelector('textarea[name="comments"]').value;

    const review = {
      rating,
      emoji,
      category,
      comments
    };

    // Save to localStorage
    let reviews = JSON.parse(localStorage.getItem('reviews')) || [];
    reviews.push(review);
    localStorage.setItem('reviews', JSON.stringify(reviews));

    // Update review section
    displayReview(review);
    form.reset();
  });

  function loadReviews() {
    const reviews = JSON.parse(localStorage.getItem('reviews')) || [];
    reviews.forEach(displayReview);
  }

  function displayReview(review) {
    const card = document.createElement('div');
    card.className = 'review-card';
    card.innerHTML = `
      <h4>⭐ ${review.rating} Stars - ${review.emoji}</h4>
      <p><strong>${review.category}:</strong> ${review.comments}</p>
    `;
    reviewsContainer.appendChild(card);
  }
});